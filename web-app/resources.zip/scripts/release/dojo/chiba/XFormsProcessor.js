/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["chiba.XFormsProcessor"]){
dojo._hasResource["chiba.XFormsProcessor"]=true;
dojo.provide("chiba.XFormsProcessor");
dojo.require("dijit._Widget");
dojo.declare("chiba.XFormsProcessor",dijit._Widget,{sessionKey:"",constructor:function(){

},init:function(){
},keepAlive:function(){
},closeSession:function(){
},ignoreExceptions:function(_1){
},dispatch:function(_2){
},setControlValue:function(id,_4){
},setRange:function(id,_6){
},setRepeatIndex:function(_7){
},_useLoadingMessage:function(){
},_handleExceptions:function(_8){
console.error(_8);
}});
}
