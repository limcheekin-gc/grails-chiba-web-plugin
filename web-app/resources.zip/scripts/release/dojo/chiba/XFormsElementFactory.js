/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["chiba.XFormsElementFactory"]){
dojo._hasResource["chiba.XFormsProcessor"]=true;
dojo.provide("chiba.XFormsElementFactory");
dojo.declare("chiba.XFormsElementFactory",null,{constructor:function(){
},createUIElement:function(_1){
}});
}
