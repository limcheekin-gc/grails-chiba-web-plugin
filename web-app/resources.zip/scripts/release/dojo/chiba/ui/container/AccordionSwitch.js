/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["chiba.ui.container.AccordionSwitch"]){
dojo._hasResource["chiba.ui.container.AccordionSwitch"]=true;
dojo.provide("chiba.ui.container.AccordionSwitch");
dojo.require("dijit.layout.AccordionContainer");
dojo.require("chiba.ui.container.Container");
dojo.declare("chiba.ui.container.AccordionSwitch",[chiba.ui.container.Container,dijit.layout.AccordionContainer],{postCreate:function(_1){
this.inherited(arguments);
},_onKeyPress:function(e){
this.inherited(arguments);
},toggleCase:function(_3){

}});
}
