/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojo.data.api.Request"]){
dojo._hasResource["dojo.data.api.Request"]=true;
dojo.provide("dojo.data.api.Request");
dojo.declare("dojo.data.api.Request",null,{abort:function(){
throw new Error("Unimplemented API: dojo.data.api.Request.abort");
}});
}
